import { ActionFormData, ModalFormData } from '@minecraft/server-ui';
import { world } from '@minecraft/server';

let bannedPlayers = [];

function showAdminMenu(player) {
    const adminMenu = new ActionFormData()
        .title("§l§2Admin Menu")
        .body("Select an admin function:")
        .button("Warn Player", "textures/ui/warn_player")
        .button("Kick Player", "textures/ui/kick_player")
        .button("Ban/Unban Player", "textures/ui/ban_unban_player")
        .button("Freeze/Unfreeze Player", "textures/ui/freeze_player");

    adminMenu.show(player).then((response) => {
        if (!response.canceled) {
            switch (response.selection) {
                case 0:
                    showWarnPlayerForm(player);
                    break;
                case 1:
                    showKickPlayerForm(player);
                    break;
                case 2:
                    showBanUnbanPlayerForm(player);
                    break;
                case 3:
                    showFreezePlayerForm(player);
                    break;
            }
        }
    });
}

function showKickPlayerForm(player) {
    const players = Array.from(world.getPlayers());
    const playerNames = players.map(p => p.name);

    const kickPlayerForm = new ModalFormData()
        .title("§l§2Kick Player")
        .dropdown("Select the player to kick:", playerNames)
        .textField("Enter the reason for kicking:", "Reason");

    kickPlayerForm.show(player).then((response) => {
        if (!response.canceled) {
            const selectedPlayerName = playerNames[response.formValues[0]];
            const kickReason = response.formValues[1];
            player.runCommand(`kick ${selectedPlayerName} ${kickReason}`);
        }
    });
}

function showBanUnbanPlayerForm(player) {
    const onlinePlayers = Array.from(world.getPlayers()).map(p => p.name);
    const bannedPlayersOptions = bannedPlayers.length > 0 ? bannedPlayers : ["No banned players"];

    const banUnbanPlayerForm = new ModalFormData()
        .title("§l§2Ban/Unban Player")
        .dropdown("Select the player to ban:", onlinePlayers.length > 0 ? onlinePlayers : ["No online players"])
        .dropdown("Select the player to unban:", bannedPlayersOptions)
        .toggle("Unban player", false);

    banUnbanPlayerForm.show(player).then((response) => {
        if (!response.canceled) {
            const playerNameToBan = onlinePlayers[response.formValues[0]];
            const playerNameToUnban = bannedPlayers[response.formValues[1]];
            const unbanPlayer = response.formValues[2];

            if (unbanPlayer && playerNameToUnban) {
                player.runCommand(`pardon ${playerNameToUnban}`);
                player.runCommand(`tellraw @a {"rawtext":[{"text":"[Server] ${playerNameToUnban} has been unbanned."}]}`);
                bannedPlayers = bannedPlayers.filter(name => name !== playerNameToUnban);
            } else if (playerNameToBan) {
                player.runCommand(`ban ${playerNameToBan}`);
                player.runCommand(`tellraw @a {"rawtext":[{"text":"[Server] ${playerNameToBan} has been banned."}]}`);
                if (!bannedPlayers.includes(playerNameToBan)) {
                    bannedPlayers.push(playerNameToBan);
                }
            }
        }
    });
}

function showWarnPlayerForm(player) {
    const players = Array.from(world.getPlayers());
    const playerNames = players.map(p => p.name);
    const warningMessages = [
        "Please follow the rules.",
        "This is your final warning.",
        "Stop spamming the chat.",
        "Respect other players."
    ];

    const warnPlayerForm = new ModalFormData()
        .title("§l§2Warn Player")
        .dropdown("Select the player to warn:", playerNames)
        .dropdown("Select a warning message:", warningMessages);

    warnPlayerForm.show(player).then((response) => {
        if (!response.canceled) {
            const selectedPlayerName = playerNames[response.formValues[0]];
            const warningMessage = warningMessages[response.formValues[1]];
            player.runCommand(`tellraw @a {"rawtext":[{"text":"[Server] @${selectedPlayerName}, ${warningMessage}"}]}`);
        }
    });
}

function showFreezePlayerForm(player) {
    const players = Array.from(world.getPlayers());
    const playerNames = players.map(p => p.name);

    const freezePlayerForm = new ModalFormData()
        .title("§l§2Freeze/Unfreeze Player")
        .dropdown("Select the player to freeze/unfreeze:", playerNames)
        .toggle("Warn player instead of freezing", true)
        .toggle("Unfreeze player", false);

    freezePlayerForm.show(player).then((response) => {
        if (!response.canceled) {
            const selectedPlayerName = playerNames[response.formValues[0]];
            const warnInsteadOfFreeze = response.formValues[1];
            const unfreezePlayer = response.formValues[2];
            if (unfreezePlayer) {
                player.runCommand(`effect ${selectedPlayerName} clear`);
                player.runCommand(`tellraw @a {"rawtext":[{"text":"[Server] ${selectedPlayerName} has been unfrozen."}]}`);
            } else if (warnInsteadOfFreeze) {
                player.runCommand(`tellraw @a {"rawtext":[{"text":"[Server] @${selectedPlayerName}, you will be frozen if you don't stop."}]}`);
            } else {
                player.runCommand(`effect ${selectedPlayerName} slowness infinite 255 true`);
                player.runCommand(`effect ${selectedPlayerName} mining_fatigue infinite 255 true`);
                player.runCommand(`tellraw @a {"rawtext":[{"text":"[Server] ${selectedPlayerName} has been frozen."}]}`);
                player.runCommand(`title ${selectedPlayerName} actionbar You are frozen! Ask in chat to be unfrozen.`);
            }
        }
    });
}

world.afterEvents.itemUse.subscribe((event) => {
    const { source, itemStack } = event;
    if (source && itemStack.typeId === "zc:admin_tool") {
        if (source.hasTag("moderator")) {
            showAdminMenu(source);
        } else {
            source.sendMessage("You do not have permission to use this tool.");
        }
    }
});
